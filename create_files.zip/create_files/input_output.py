#question_1

def temperature_conversion(Type, temperature):
    
    if Type == 'C':
        return (temperature * 9/5) + 32
    elif Type == 'F':
        return (temperature - 32) * 5/9
    else:
        return "Invalid Input"
    
# print("Enter the temperature As Celsius(C) or Fahrenheit(F):")
# Type = input()
# print("Enter the temperature: ")
# temperature = float(input())
# print("The temperature is: ", temperature_conversion(Type, temperature), "° in ", Type)

#question_2

def count_words(file):
    try:
        with open(file, 'r') as file:
            text = file.read()
            # Replace commas without spaces with spaces
            text = text.replace(',', ' ')
            # Split the text into words
            words = text.split()
            # Count the number of words
            word_count = len(words)
            return word_count
    except FileNotFoundError:
        print(f"Error: File '{file}' not found.")
    except Exception as e:
        print(f"Error: {e}")

# file = 'test.txt'  
# result = count_words(file)

# if result is not None:
#     print(f"Number of words in '{file}': {result}")


def combine_files(file1_path, file2_path):
    try:
        with open(file1_path, 'r') as file1, open(file2_path, 'r') as file2:
            for line1, line2 in zip(file1, file2):
                combined_line = f"{line1.strip()} {line2.strip()}"
                print(combined_line)
    except FileNotFoundError:
        print("One or both of the files not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

# # Example usage:
# file1_path = 'test1.txt'  # Replace with your actual file paths
# file2_path = 'test2.txt'

# combine_files(file1_path, file2_path)

 